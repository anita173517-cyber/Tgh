# StreamX Media3 Pro v14.1 — TV Experience Upgrade

## UI / Interface
- Refined 4D glass visual language across top navigation, channel drawer, channel cards, dialogs, input fields, badges, logo frames and action buttons.
- Improved focus-state contrast and layered highlights for remote/D-pad use.
- Reworked the bottom zapping HUD into a compact 96dp layout with tighter spacing, a smaller logo, more legible text hierarchy and compact controls. All existing view IDs and click wiring are retained.
- Constrained the channel title/category row to available width to reduce clipping on smaller TV resolutions.

## TV / Playback / Memory
- Preserved the existing Media3 1.11.1 player, HLS preload-to-playback handoff, 320KB bounded preload RAM cache, generation cancellation, 512MB buffer profile, focus prefetch and rapid channel-switch path.
- Preserved existing M3U/Xtream/XMLTV/EPG, favourites, profiles, PIN, boot overlay, sleep, aspect, audio/video and remote controls.
- No speculative second-player or decoder allocation was introduced.

## Build compatibility
- Kept Android Gradle Plugin 8.13.2, Kotlin 2.2.20, compileSdk 36, JDK 17 target and Media3 1.11.1 unchanged to match the supplied Gradle 8.13 / JDK 17 / SDK 36 workflow.
- `scripts/verify_project.py` passes locally. GitHub Gradle unit tests and APK build still require CI execution.
