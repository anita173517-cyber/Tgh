package com.harindra.iptvpro.vod

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.request.RequestOptions
import com.harindra.iptvpro.ProfileStore
import com.harindra.iptvpro.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * RAM PLAYER v21.0 — Dedicated Premium OTT VOD Player Activity.
 *
 * Completely independent from Live TV (`PlayerActivity`, Live TV `ExoPlayer`, Live TV `PlayerView`,
 * Live TV OSD, channel switching, and Live TV reconnect logic).
 *
 * Features:
 * - Dedicated Media3 ExoPlayer & PlayerView with low-RAM adaptive buffering
 * - 4D Glassmorphism dark cinema UI with auto-hiding TV-remote-first controls
 * - Configurable seek intervals (5/10/15/20/30/60s), long-press continuous seek & preview
 * - Real Media3 Video Quality selection (Auto + genuine available tracks / honest fixed-stream info)
 * - Real Audio Track selection (language, codec, channel layout) + Audio Sync delay
 * - Advanced Subtitle system (Off, embedded/external tracks, TV-readable styling, font size, delay)
 * - Playback speed (0.5x–2.0x) & Aspect Ratios (Fit, Fill, Zoom, Stretch, Original)
 * - Smart Movie resume/completion & Smart Series season/episode drawer + single-trigger Auto-Next
 * - Bounded VOD error recovery (never infinite retry, never touches Live TV)
 */
@OptIn(UnstableApi::class)
class VodPlayerActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var loadingOverlay: View
    private lateinit var ivLoadingBackdrop: ImageView
    private lateinit var ivLoadingPoster: ImageView
    private lateinit var tvLoadingTitle: TextView
    private lateinit var tvLoadingSubtitle: TextView
    private lateinit var tvLoadingStatus: TextView

    private lateinit var seekPreviewPill: View
    private lateinit var tvSeekDelta: TextView
    private lateinit var tvSeekTargetTime: TextView
    private lateinit var rebufferPill: View
    private lateinit var tvRebufferText: TextView

    private lateinit var controlsContainer: View
    private lateinit var btnBack: Button
    private lateinit var tvTitle: TextView
    private lateinit var tvSubtitleMeta: TextView
    private lateinit var tvStatusBadge: TextView
    private lateinit var tvQualityBadge: TextView
    private lateinit var tvClock: TextView

    private lateinit var tvCurrentTime: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var tvTotalDuration: TextView

    private lateinit var btnPrevEpisode: Button
    private lateinit var btnRewind: Button
    private lateinit var btnPlayPause: Button
    private lateinit var btnForward: Button
    private lateinit var btnNextEpisode: Button
    private lateinit var btnQuality: Button
    private lateinit var btnAudio: Button
    private lateinit var btnSubtitles: Button
    private lateinit var btnSpeed: Button
    private lateinit var btnAspect: Button
    private lateinit var btnEpisodes: Button
    private lateinit var btnSettings: Button

    private lateinit var autoNextCard: View
    private lateinit var tvAutoNextBadge: TextView
    private lateinit var tvAutoNextTitle: TextView
    private lateinit var pbAutoNextCountdown: ProgressBar
    private lateinit var btnAutoNextPlayNow: Button
    private lateinit var btnAutoNextCancel: Button

    private lateinit var errorOverlay: View
    private lateinit var tvErrorTitle: TextView
    private lateinit var tvErrorMessage: TextView
    private lateinit var btnErrorRetry: Button
    private lateinit var btnErrorBack: Button

    private lateinit var vodPrefs: VodPreferencesStore
    private lateinit var profileStore: ProfileStore
    private lateinit var progressStore: VodProgressStore
    private lateinit var playbackManager: VodPlaybackManager
    private lateinit var seekController: VodSeekController
    private lateinit var trackManager: VodTrackSelectionManager
    private lateinit var subtitleController: VodSubtitleController
    private lateinit var errorHandler: VodPlaybackErrorHandler
    private lateinit var autoNextController: VodAutoNextController
    private lateinit var remoteController: VodRemoteControlController

    private var payload: VodLaunchPayload? = null
    private var currentEpisode: VodEpisodeNavItem? = null
    private var currentStreamUrl: String = ""
    private var currentContentId: String = ""
    private var currentTitle: String = ""
    private var activeDialog: AlertDialog? = null
    private var pendingAutoNextEpisode: VodEpisodeNavItem? = null
    private var autoNextRemainingSec: Int = 0
    private var autoNextTotalSec: Int = 10
    private var controlsVisible: Boolean = true
    private var userDraggingSeekBar: Boolean = false
    private var appliedInitialQualityPref: Boolean = false
    private var playbackState: VodPlaybackState = VodPlaybackState()

    private val uiHandler = Handler(Looper.getMainLooper())
    private val clockFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

    private val hideControlsRunnable = Runnable {
        if (controlsVisible && activeDialog?.isShowing != true && !userDraggingSeekBar && errorOverlay.visibility != View.VISIBLE) {
            setControlsVisible(false)
        }
    }

    private val hideSeekPreviewRunnable = Runnable {
        seekPreviewPill.visibility = View.GONE
    }

    private val progressTickRunnable = object : Runnable {
        override fun run() {
            updateTimelineFromPlayer()
            checkAutoNextIfEligible()
            tvClock.text = clockFormat.format(Date())
            uiHandler.postDelayed(this, 500L)
        }
    }

    private val periodicSaveRunnable = object : Runnable {
        override fun run() {
            saveCurrentPlaybackProgress()
            uiHandler.postDelayed(this, 10_000L)
        }
    }

    private val autoNextTickRunnable = object : Runnable {
        override fun run() {
            val nextEp = pendingAutoNextEpisode ?: return
            if (autoNextCard.visibility != View.VISIBLE) return
            if (autoNextRemainingSec <= 0) {
                hideAutoNextCard()
                switchToEpisode(nextEp, resumePositionMs = 0L)
                return
            }
            tvAutoNextBadge.text = "UP NEXT IN ${autoNextRemainingSec}s"
            val pct = ((autoNextRemainingSec * 100) / autoNextTotalSec.coerceAtLeast(1)).coerceIn(0, 100)
            pbAutoNextCountdown.progress = pct
            autoNextRemainingSec--
            uiHandler.postDelayed(this, 1_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_vod_player)

        val parsed = VodPlayerLauncher.parsePayload(intent)
        if (parsed == null) {
            Toast.makeText(this, "Invalid VOD item", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        payload = parsed

        vodPrefs = VodPreferencesStore(this)
        profileStore = ProfileStore(this)
        progressStore = VodProgressStore(ProfileStoreVodProgressAdapter(profileStore))
        playbackManager = VodPlaybackManager(this, vodPrefs)
        seekController = VodSeekController(vodPrefs.getDefaultSeekInterval())
        trackManager = VodTrackSelectionManager()
        subtitleController = VodSubtitleController(vodPrefs)
        errorHandler = VodPlaybackErrorHandler(maxTransientRetries = 3)
        autoNextController = VodAutoNextController(parsed.episodes)
        remoteController = VodRemoteControlController()

        bindViews()
        setupListeners()
        applySavedUiPreferences()
        startPayloadPlayback(parsed)
    }

    private fun bindViews() {
        playerView = findViewById(R.id.vodPlayerView)
        loadingOverlay = findViewById(R.id.vodLoadingOverlay)
        ivLoadingBackdrop = findViewById(R.id.ivVodLoadingBackdrop)
        ivLoadingPoster = findViewById(R.id.ivVodLoadingPoster)
        tvLoadingTitle = findViewById(R.id.tvVodLoadingTitle)
        tvLoadingSubtitle = findViewById(R.id.tvVodLoadingSubtitle)
        tvLoadingStatus = findViewById(R.id.tvVodLoadingStatus)

        seekPreviewPill = findViewById(R.id.vodSeekPreviewPill)
        tvSeekDelta = findViewById(R.id.tvVodSeekDelta)
        tvSeekTargetTime = findViewById(R.id.tvVodSeekTargetTime)
        rebufferPill = findViewById(R.id.vodRebufferPill)
        tvRebufferText = findViewById(R.id.tvVodRebufferText)

        controlsContainer = findViewById(R.id.vodControlsContainer)
        btnBack = findViewById(R.id.btnVodBack)
        tvTitle = findViewById(R.id.tvVodTitle)
        tvSubtitleMeta = findViewById(R.id.tvVodSubtitleMeta)
        tvStatusBadge = findViewById(R.id.tvVodPlaybackStatusBadge)
        tvQualityBadge = findViewById(R.id.tvVodQualityBadge)
        tvClock = findViewById(R.id.tvVodClock)

        tvCurrentTime = findViewById(R.id.tvVodCurrentTime)
        seekBar = findViewById(R.id.vodSeekBar)
        tvTotalDuration = findViewById(R.id.tvVodTotalDuration)

        btnPrevEpisode = findViewById(R.id.btnVodPrevEpisode)
        btnRewind = findViewById(R.id.btnVodRewind)
        btnPlayPause = findViewById(R.id.btnVodPlayPause)
        btnForward = findViewById(R.id.btnVodForward)
        btnNextEpisode = findViewById(R.id.btnVodNextEpisode)
        btnQuality = findViewById(R.id.btnVodQuality)
        btnAudio = findViewById(R.id.btnVodAudio)
        btnSubtitles = findViewById(R.id.btnVodSubtitles)
        btnSpeed = findViewById(R.id.btnVodSpeed)
        btnAspect = findViewById(R.id.btnVodAspect)
        btnEpisodes = findViewById(R.id.btnVodEpisodes)
        btnSettings = findViewById(R.id.btnVodSettings)

        autoNextCard = findViewById(R.id.vodAutoNextCard)
        tvAutoNextBadge = findViewById(R.id.tvVodAutoNextBadge)
        tvAutoNextTitle = findViewById(R.id.tvVodAutoNextTitle)
        pbAutoNextCountdown = findViewById(R.id.pbVodAutoNextCountdown)
        btnAutoNextPlayNow = findViewById(R.id.btnVodAutoNextPlayNow)
        btnAutoNextCancel = findViewById(R.id.btnVodAutoNextCancel)

        errorOverlay = findViewById(R.id.vodErrorOverlay)
        tvErrorTitle = findViewById(R.id.tvVodErrorTitle)
        tvErrorMessage = findViewById(R.id.tvVodErrorMessage)
        btnErrorRetry = findViewById(R.id.btnVodErrorRetry)
        btnErrorBack = findViewById(R.id.btnVodErrorBack)
    }

    private fun setupListeners() {
        btnBack.setOnClickListener { exitToDetails() }
        btnPlayPause.setOnClickListener {
            togglePlayPause()
            scheduleControlsAutoHide()
        }
        btnRewind.setOnClickListener {
            performStepSeek(isForward = false)
            scheduleControlsAutoHide()
        }
        btnForward.setOnClickListener {
            performStepSeek(isForward = true)
            scheduleControlsAutoHide()
        }
        btnPrevEpisode.setOnClickListener {
            val prev = autoNextController.findPreviousEpisode(currentContentId)
            if (prev != null) {
                switchToEpisode(prev, resumePositionMs = 0L)
            } else {
                Toast.makeText(this, "This is the first episode", Toast.LENGTH_SHORT).show()
            }
        }
        btnNextEpisode.setOnClickListener {
            val next = autoNextController.findNextEpisode(currentContentId)
            if (next != null) {
                switchToEpisode(next, resumePositionMs = 0L)
            } else {
                Toast.makeText(this, "No next episode available", Toast.LENGTH_SHORT).show()
            }
        }
        btnQuality.setOnClickListener { showQualitySelectorDialog() }
        btnAudio.setOnClickListener { showAudioSelectorDialog() }
        btnSubtitles.setOnClickListener { showSubtitleSelectorDialog() }
        btnSpeed.setOnClickListener { showSpeedSelectorDialog() }
        btnAspect.setOnClickListener { showAspectRatioDialog() }
        btnEpisodes.setOnClickListener { showEpisodesDrawerDialog() }
        btnSettings.setOnClickListener { showVodSettingsDialog() }

        btnAutoNextPlayNow.setOnClickListener {
            val nextEp = pendingAutoNextEpisode
            hideAutoNextCard()
            if (nextEp != null) {
                switchToEpisode(nextEp, resumePositionMs = 0L)
            }
        }
        btnAutoNextCancel.setOnClickListener {
            autoNextController.cancelForEpisode(currentContentId)
            hideAutoNextCard()
            Toast.makeText(this, "Auto-next cancelled", Toast.LENGTH_SHORT).show()
        }

        btnErrorRetry.setOnClickListener {
            errorHandler.reset()
            errorOverlay.visibility = View.GONE
            loadingOverlay.visibility = View.VISIBLE
            tvLoadingStatus.text = "Retrying stream connection..."
            val resumePos = playbackManager.getPlayer()?.currentPosition?.coerceAtLeast(0L)
                ?: payload?.resumePositionMs ?: 0L
            startMediaStream(currentStreamUrl, resumePos)
        }
        btnErrorBack.setOnClickListener { exitToDetails() }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val player = playbackManager.getPlayer() ?: return
                val dur = player.duration
                if (dur > 0L && dur != C.TIME_UNSET) {
                    val target = (dur * progress.toLong()) / 10_000L
                    tvCurrentTime.text = VodTimeFormatter.formatMs(target)
                    showSeekPreviewPill(
                        deltaLabel = "⏱ ${VodTimeFormatter.formatMs(target)}",
                        targetTimeLabel = "${VodTimeFormatter.formatMs(target)} / ${VodTimeFormatter.formatMs(dur)}"
                    )
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                userDraggingSeekBar = true
                uiHandler.removeCallbacks(hideControlsRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                userDraggingSeekBar = false
                val player = playbackManager.getPlayer()
                val dur = player?.duration ?: C.TIME_UNSET
                if (player != null && dur > 0L && dur != C.TIME_UNSET && sb != null) {
                    val target = (dur * sb.progress.toLong()) / 10_000L
                    player.seekTo(target.coerceIn(0L, dur))
                }
                scheduleControlsAutoHide()
            }
        })

        playerView.setOnClickListener {
            setControlsVisible(!controlsVisible)
        }
    }

    private fun applySavedUiPreferences() {
        val interval = vodPrefs.getDefaultSeekInterval()
        seekController.setDefaultInterval(interval)
        btnRewind.text = "⏪ ${interval.label}"
        btnForward.text = "${interval.label} ⏩"

        val speed = vodPrefs.getDefaultPlaybackSpeed()
        btnSpeed.text = speed.label

        val aspect = vodPrefs.getAspectRatioMode()
        btnAspect.text = aspect.label
        playbackManager.applyAspectRatio(playerView, aspect)
        subtitleController.applyStylingToPlayerView(playerView)
    }

    private fun startPayloadPlayback(data: VodLaunchPayload) {
        currentContentId = data.contentId
        currentStreamUrl = data.streamUrl
        currentTitle = data.title

        if (data.contentType == VodContentType.SERIES_EPISODE) {
            currentEpisode = data.episodes.firstOrNull { it.episodeId == data.contentId }
                ?: VodEpisodeNavItem(
                    episodeId = data.contentId,
                    seriesId = data.seriesId,
                    seriesKey = data.seriesKey,
                    seriesTitle = data.seriesTitle.ifBlank { data.title },
                    seasonNumber = data.seasonNumber.coerceAtLeast(1),
                    episodeNumber = data.episodeNumber.coerceAtLeast(1),
                    episodeTitle = data.title,
                    streamUrl = data.streamUrl,
                    posterUrl = data.posterUrl,
                    durationLabel = data.durationLabel,
                    containerExtension = data.containerExtension
                )
        } else {
            currentEpisode = null
        }

        updateHeaderAndSeriesControls(
            title = data.title,
            subtitle = data.subtitleLine.ifBlank {
                listOfNotNull(
                    data.category.takeIf { it.isNotBlank() },
                    data.releaseYear.takeIf { it.isNotBlank() },
                    data.containerExtension.uppercase(Locale.ROOT).takeIf { it.isNotBlank() }
                ).joinToString(" • ").ifBlank { "RAM PLAYER CINEMA" }
            },
            posterUrl = data.posterUrl,
            backdropUrl = data.backdropUrl.ifBlank { data.posterUrl }
        )

        val effectiveResumeMs = if (data.resumePositionMs > 0L) {
            data.resumePositionMs
        } else {
            progressStore.getResumePositionMs(
                contentId = data.contentId,
                accountScope = data.accountScope,
                resumeEnabled = vodPrefs.isResumePlaybackEnabled()
            )
        }

        val player = playbackManager.getOrCreatePlayer()
        playerView.player = player
        subtitleController.applyStylingToPlayerView(playerView)
        player.addListener(vodPlayerListener)

        startMediaStream(
            streamUrl = data.streamUrl,
            resumePositionMs = effectiveResumeMs,
            extSubUrl = data.externalSubtitleUrl,
            extSubLang = data.externalSubtitleLanguage
        )
        uiHandler.removeCallbacks(progressTickRunnable)
        uiHandler.post(progressTickRunnable)
        uiHandler.removeCallbacks(periodicSaveRunnable)
        uiHandler.postDelayed(periodicSaveRunnable, 10_000L)
    }

    private fun updateHeaderAndSeriesControls(
        title: String,
        subtitle: String,
        posterUrl: String,
        backdropUrl: String
    ) {
        tvTitle.text = title
        tvSubtitleMeta.text = subtitle
        tvLoadingTitle.text = title
        tvLoadingSubtitle.text = subtitle

        val glideOpts = RequestOptions()
            .format(DecodeFormat.PREFER_RGB_565)
            .override(320, 480)
            .centerCrop()
        if (posterUrl.isNotBlank()) {
            Glide.with(this).load(posterUrl).apply(glideOpts).into(ivLoadingPoster)
        } else {
            ivLoadingPoster.setImageResource(
                if (payload?.contentType == VodContentType.SERIES_EPISODE) R.drawable.ic_3d_series else R.drawable.ic_3d_movies
            )
        }
        if (backdropUrl.isNotBlank()) {
            Glide.with(this)
                .load(backdropUrl)
                .apply(RequestOptions().format(DecodeFormat.PREFER_RGB_565).override(640, 360).centerCrop())
                .into(ivLoadingBackdrop)
        }

        val isSeries = payload?.contentType == VodContentType.SERIES_EPISODE
        val hasPrev = isSeries && autoNextController.findPreviousEpisode(currentContentId) != null
        val hasNext = isSeries && autoNextController.findNextEpisode(currentContentId) != null
        btnPrevEpisode.visibility = if (hasPrev) View.VISIBLE else View.GONE
        btnNextEpisode.visibility = if (hasNext) View.VISIBLE else View.GONE
        btnEpisodes.visibility = if (isSeries && (payload?.episodes?.isNotEmpty() == true)) View.VISIBLE else View.GONE
    }

    private fun startMediaStream(
        streamUrl: String,
        resumePositionMs: Long,
        extSubUrl: String = "",
        extSubLang: String = "en"
    ) {
        errorOverlay.visibility = View.GONE
        loadingOverlay.visibility = View.VISIBLE
        rebufferPill.visibility = View.GONE
        hideAutoNextCard()
        appliedInitialQualityPref = false
        tvLoadingStatus.text = if (resumePositionMs > 10_000L) {
            "Resuming from ${VodTimeFormatter.formatMs(resumePositionMs)}..."
        } else {
            "Connecting to VOD stream..."
        }
        val ok = playbackManager.prepareMedia(
            streamUrl = streamUrl,
            resumePositionMs = resumePositionMs,
            externalSubtitleUrl = extSubUrl,
            externalSubtitleLanguage = extSubLang
        )
        if (!ok) {
            showVodError(errorHandler.classifyInvalidUrl())
        }
    }

    private val vodPlayerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> {
                    if (loadingOverlay.visibility != View.VISIBLE) {
                        rebufferPill.visibility = View.VISIBLE
                        val pct = playbackManager.getPlayer()?.bufferedPercentage ?: 0
                        tvRebufferText.text = "Buffering ($pct%)..."
                    } else {
                        tvLoadingStatus.text = "Buffering cinema stream..."
                    }
                    tvStatusBadge.text = "BUFFERING"
                    tvStatusBadge.setTextColor(Color.parseColor("#FBBF24"))
                }
                Player.STATE_READY -> {
                    loadingOverlay.visibility = View.GONE
                    rebufferPill.visibility = View.GONE
                    errorOverlay.visibility = View.GONE
                    errorHandler.reset()
                    updatePlayPauseUi()
                    updateTrackBadges()
                    scheduleControlsAutoHide()
                }
                Player.STATE_ENDED -> {
                    rebufferPill.visibility = View.GONE
                    saveCurrentPlaybackProgress(forceCompleteIfEnded = true)
                    tvStatusBadge.text = "COMPLETED"
                    tvStatusBadge.setTextColor(Color.parseColor("#38BDF8"))
                    btnPlayPause.text = "↻ Replay"
                    val handledAutoNext = checkAutoNextIfEligible(playbackEnded = true)
                    if (!handledAutoNext) {
                        setControlsVisible(true)
                    }
                }
                Player.STATE_IDLE -> {
                    rebufferPill.visibility = View.GONE
                }
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlayPauseUi()
            if (!isPlaying) {
                saveCurrentPlaybackProgress()
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            val player = playbackManager.getPlayer() ?: return
            if (!appliedInitialQualityPref) {
                appliedInitialQualityPref = true
                trackManager.applyPreferredQualityByLabel(player, vodPrefs.getDefaultQualityMode())
            }
            updateTrackBadges()
        }

        override fun onPlayerError(error: PlaybackException) {
            saveCurrentPlaybackProgress()
            val info = errorHandler.classifyException(error)
            val delayMs = errorHandler.nextRetryDelayMs(info)
            if (delayMs != null) {
                loadingOverlay.visibility = View.VISIBLE
                tvLoadingStatus.text = "${info.title} — Retrying (${errorHandler.currentRetryCount()}/${info.maxRetries})..."
                val resumePos = playbackManager.getPlayer()?.currentPosition?.coerceAtLeast(0L) ?: 0L
                uiHandler.postDelayed({
                    if (!isFinishing && !isDestroyed) {
                        startMediaStream(currentStreamUrl, resumePos)
                    }
                }, delayMs)
            } else {
                showVodError(info)
            }
        }
    }

    private fun updatePlayPauseUi() {
        val player = playbackManager.getPlayer()
        val playing = player?.isPlaying == true
        btnPlayPause.text = if (playing) "⏸ Pause" else "▶ Play"
        tvStatusBadge.text = if (playing) "PLAYING" else "PAUSED"
        tvStatusBadge.setTextColor(
            Color.parseColor(if (playing) "#6EE7B7" else "#FDE047")
        )
    }

    private fun updateTrackBadges() {
        val player = playbackManager.getPlayer() ?: return
        val q = trackManager.inspectVideoQualities(player)
        tvQualityBadge.text = q.currentResolutionLabel.uppercase(Locale.ROOT)
        playbackState = playbackState.copy(
            currentQualityLabel = q.currentResolutionLabel,
            isAutoQuality = q.isAutoMode,
            isAdaptiveStream = q.isAdaptiveStream,
            currentAudioLabel = trackManager.getCurrentAudioSummary(player),
            currentSubtitleLabel = trackManager.getCurrentSubtitleSummary(player)
        )
    }

    private fun updateTimelineFromPlayer() {
        val player = playbackManager.getPlayer() ?: return
        val pos = player.currentPosition.coerceAtLeast(0L)
        val buffered = player.bufferedPosition.coerceAtLeast(pos)
        val dur = player.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
        val isSeekable = player.isCurrentMediaItemSeekable

        if (!userDraggingSeekBar && !seekController.isContinuousScrubbing()) {
            tvCurrentTime.text = VodTimeFormatter.formatMs(pos)
            tvTotalDuration.text = if (dur > 0L) VodTimeFormatter.formatMs(dur) else "--:--"
            if (dur > 0L) {
                seekBar.isEnabled = isSeekable
                seekBar.progress = ((pos * 10_000L) / dur).toInt().coerceIn(0, 10_000)
                seekBar.secondaryProgress = ((buffered * 10_000L) / dur).toInt().coerceIn(0, 10_000)
            } else {
                seekBar.isEnabled = false
                seekBar.progress = 0
                seekBar.secondaryProgress = 0
            }
        }
    }

    private fun togglePlayPause() {
        val player = playbackManager.getPlayer() ?: return
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0L)
            player.playWhenReady = true
            return
        }
        player.playWhenReady = !player.playWhenReady
        updatePlayPauseUi()
    }

    private fun performStepSeek(isForward: Boolean) {
        val player = playbackManager.getPlayer() ?: return
        val dur = player.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
        val preview = seekController.computeStepSeek(
            currentPositionMs = player.currentPosition,
            durationMs = dur,
            isSeekable = player.isCurrentMediaItemSeekable,
            isForward = isForward
        ) ?: return
        player.seekTo(preview.targetPositionMs)
        val arrow = if (isForward) "⏩" else "⏪"
        showSeekPreviewPill(
            deltaLabel = "$arrow ${preview.formattedDelta()}",
            targetTimeLabel = "${preview.formattedTarget()} / ${preview.formattedDuration()}"
        )
        updateTimelineFromPlayer()
    }

    private fun performContinuousSeekStep(isForward: Boolean) {
        val player = playbackManager.getPlayer() ?: return
        val dur = player.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
        val preview = seekController.onContinuousSeekStep(
            currentPositionMs = player.currentPosition,
            durationMs = dur,
            isSeekable = player.isCurrentMediaItemSeekable,
            isForward = isForward
        ) ?: return
        val arrow = if (isForward) "⏩" else "⏪"
        showSeekPreviewPill(
            deltaLabel = "$arrow ${preview.formattedDelta()}",
            targetTimeLabel = "${preview.formattedTarget()} / ${preview.formattedDuration()}"
        )
        tvCurrentTime.text = preview.formattedTarget()
        if (dur > 0L) {
            seekBar.progress = ((preview.targetPositionMs * 10_000L) / dur).toInt().coerceIn(0, 10_000)
        }
    }

    private fun commitContinuousSeek() {
        val target = seekController.commitContinuousSeek() ?: return
        playbackManager.getPlayer()?.seekTo(target)
        updateTimelineFromPlayer()
    }

    private fun showSeekPreviewPill(deltaLabel: String, targetTimeLabel: String) {
        tvSeekDelta.text = deltaLabel
        tvSeekTargetTime.text = targetTimeLabel
        seekPreviewPill.visibility = View.VISIBLE
        uiHandler.removeCallbacks(hideSeekPreviewRunnable)
        uiHandler.postDelayed(hideSeekPreviewRunnable, 1_400L)
    }

    private fun checkAutoNextIfEligible(playbackEnded: Boolean = false): Boolean {
        val data = payload ?: return false
        if (data.contentType != VodContentType.SERIES_EPISODE) return false
        val player = playbackManager.getPlayer() ?: return false
        val dur = player.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
        val nextEp = autoNextController.evaluateAutoNextTrigger(
            contentType = data.contentType,
            currentEpisodeId = currentContentId,
            positionMs = player.currentPosition,
            durationMs = dur,
            playbackEnded = playbackEnded,
            autoNextEnabled = vodPrefs.isAutoNextEpisodeEnabled()
        ) ?: return false

        pendingAutoNextEpisode = nextEp
        autoNextTotalSec = vodPrefs.getAutoNextCountdownSec()
        autoNextRemainingSec = autoNextTotalSec
        tvAutoNextTitle.text = "${nextEp.seasonEpisodeBadge()} • ${nextEp.episodeTitle}"
        autoNextCard.visibility = View.VISIBLE
        btnAutoNextPlayNow.post { btnAutoNextPlayNow.requestFocus() }
        uiHandler.removeCallbacks(autoNextTickRunnable)
        uiHandler.post(autoNextTickRunnable)
        return true
    }

    private fun hideAutoNextCard() {
        uiHandler.removeCallbacks(autoNextTickRunnable)
        pendingAutoNextEpisode = null
        autoNextCard.visibility = View.GONE
    }

    private fun switchToEpisode(ep: VodEpisodeNavItem, resumePositionMs: Long) {
        saveCurrentPlaybackProgress()
        hideAutoNextCard()
        currentEpisode = ep
        currentContentId = ep.episodeId
        currentStreamUrl = ep.streamUrl
        currentTitle = "${ep.seriesTitle} • ${ep.seasonEpisodeBadge()} ${ep.episodeTitle}"
        autoNextController.resetForEpisode(ep.episodeId)
        errorHandler.reset()

        val data = payload
        updateHeaderAndSeriesControls(
            title = currentTitle,
            subtitle = "Season ${ep.seasonNumber}, Episode ${ep.episodeNumber}" +
                if (ep.durationLabel.isNotBlank()) " • ${ep.durationLabel}" else "",
            posterUrl = ep.posterUrl.ifBlank { data?.posterUrl.orEmpty() },
            backdropUrl = data?.backdropUrl.orEmpty().ifBlank { ep.posterUrl }
        )

        val effectiveResume = if (resumePositionMs > 0L) {
            resumePositionMs
        } else {
            progressStore.getResumePositionMs(
                contentId = ep.episodeId,
                accountScope = data?.accountScope ?: "default",
                resumeEnabled = vodPrefs.isResumePlaybackEnabled()
            )
        }
        startMediaStream(ep.streamUrl, effectiveResume)
    }

    private fun showVodError(info: VodErrorInfo) {
        loadingOverlay.visibility = View.GONE
        rebufferPill.visibility = View.GONE
        hideAutoNextCard()
        setControlsVisible(false)
        tvErrorTitle.text = info.title
        tvErrorMessage.text = info.message
        btnErrorRetry.visibility = if (info.category.isRetryable) View.VISIBLE else View.GONE
        errorOverlay.visibility = View.VISIBLE
        if (btnErrorRetry.visibility == View.VISIBLE) {
            btnErrorRetry.post { btnErrorRetry.requestFocus() }
        } else {
            btnErrorBack.post { btnErrorBack.requestFocus() }
        }
    }

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible
        controlsContainer.visibility = if (visible) View.VISIBLE else View.GONE
        if (visible) {
            btnPlayPause.post { btnPlayPause.requestFocus() }
            scheduleControlsAutoHide()
        } else {
            uiHandler.removeCallbacks(hideControlsRunnable)
        }
    }

    private fun scheduleControlsAutoHide() {
        uiHandler.removeCallbacks(hideControlsRunnable)
        if (controlsVisible) {
            uiHandler.postDelayed(hideControlsRunnable, vodPrefs.getControlsAutoHideMs())
        }
    }

    private fun saveCurrentPlaybackProgress(forceCompleteIfEnded: Boolean = false) {
        val data = payload ?: return
        val player = playbackManager.getPlayer() ?: return
        val dur = player.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
        val pos = if (forceCompleteIfEnded && dur > 0L) dur else player.currentPosition.coerceAtLeast(0L)
        val ep = currentEpisode
        progressStore.recordProgress(
            contentType = data.contentType,
            contentId = currentContentId,
            positionMs = pos,
            durationMs = dur,
            accountScope = data.accountScope,
            seriesKey = ep?.seriesKey ?: data.seriesKey,
            seasonNumber = ep?.seasonNumber ?: data.seasonNumber,
            episodeNumber = ep?.episodeNumber ?: data.episodeNumber
        )
    }

    // =========================================================================
    // 4D GLASSMORPHISM SELECTOR PANELS (QUALITY, AUDIO, SUBTITLES, SPEED, ASPECT, EPISODES, SETTINGS)
    // =========================================================================

    private fun showQualitySelectorDialog() {
        val player = playbackManager.getPlayer() ?: return
        val inspection = trackManager.inspectVideoQualities(player)
        val items = inspection.options.map { opt ->
            val sub = when {
                opt.isAuto -> "Adaptive bitrate — automatically matches bandwidth"
                opt.bitrateBps > 0 -> "${opt.width}×${opt.height} • ${opt.bitrateBadge()}"
                else -> "${opt.width}×${opt.height}"
            }
            PanelRow(
                title = opt.label,
                subtitle = sub,
                badge = if (opt.isSelected) "ACTIVE ✓" else if (opt.isAuto) "AUTO" else "SELECT",
                selected = opt.isSelected
            ) {
                trackManager.selectVideoQuality(player, opt)
                vodPrefs.setDefaultQualityMode(if (opt.isAuto) "AUTO" else opt.label)
                updateTrackBadges()
                Toast.makeText(this, "Video Quality: ${opt.label}", Toast.LENGTH_SHORT).show()
            }
        }
        val subtitle = if (!inspection.isAdaptiveStream) {
            inspection.fixedStreamReason
        } else {
            "Current: ${inspection.currentResolutionLabel} • Switch without restarting playback"
        }
        presentGlassSelectorPanel("Video Quality", subtitle, items)
    }

    private fun showAudioSelectorDialog() {
        val player = playbackManager.getPlayer() ?: return
        val tracks = trackManager.inspectAudioTracks(player)
        val items = ArrayList<PanelRow>()
        for (track in tracks) {
            val sub = if (track.isAuto) {
                "Automatically selects original / preferred audio language"
            } else {
                listOf(track.codecName, track.channelLayout).filter { it.isNotBlank() }.joinToString(" • ")
            }
            items.add(
                PanelRow(
                    title = track.label,
                    subtitle = sub,
                    badge = if (track.isSelected) "ACTIVE ✓" else "SELECT",
                    selected = track.isSelected
                ) {
                    trackManager.selectAudioTrack(player, track)
                    if (!track.isAuto && track.languageCode.isNotBlank()) {
                        vodPrefs.setPreferredAudioLanguage(track.languageCode)
                    } else if (track.isAuto) {
                        vodPrefs.setPreferredAudioLanguage("original")
                    }
                    updateTrackBadges()
                    Toast.makeText(this, "Audio: ${track.languageDisplay}", Toast.LENGTH_SHORT).show()
                }
            )
        }
        val currentDelay = playbackManager.audioDelayProcessor.getDelayMs()
        items.add(
            PanelRow(
                title = "Audio Sync Delay: +${currentDelay} ms",
                subtitle = "Cycle lip-sync audio delay (0 / 100 / 200 / 300 / 400 ms)",
                badge = "SYNC",
                selected = currentDelay > 0
            ) {
                val next = if (currentDelay >= 400) 0 else currentDelay + 100
                playbackManager.audioDelayProcessor.setDelayMs(next)
                Toast.makeText(this, "Audio Delay: +${next} ms", Toast.LENGTH_SHORT).show()
            }
        )
        presentGlassSelectorPanel("Audio Tracks & Sync", "Current: ${trackManager.getCurrentAudioSummary(player)}", items)
    }

    private fun showSubtitleSelectorDialog() {
        val player = playbackManager.getPlayer() ?: return
        val tracks = trackManager.inspectSubtitleTracks(player)
        val items = ArrayList<PanelRow>()
        for (track in tracks) {
            items.add(
                PanelRow(
                    title = track.label,
                    subtitle = if (track.isOff) "Hide all subtitles" else track.mimeType.ifBlank { "Embedded subtitle track" },
                    badge = if (track.isSelected) "ACTIVE ✓" else "SELECT",
                    selected = track.isSelected
                ) {
                    trackManager.selectSubtitleTrack(player, track)
                    vodPrefs.setSubtitlesDefaultEnabled(!track.isOff)
                    if (!track.isOff && track.languageCode.isNotBlank()) {
                        vodPrefs.setPreferredSubtitleLanguage(track.languageCode)
                    }
                    updateTrackBadges()
                    Toast.makeText(this, "Subtitles: ${track.languageDisplay}", Toast.LENGTH_SHORT).show()
                }
            )
        }
        val curFont = vodPrefs.getSubtitleFontSize()
        items.add(
            PanelRow(
                title = "Subtitle Font Size: ${curFont.label}",
                subtitle = "Cycle Small / Medium / Large / Extra Large for TV readability",
                badge = "SIZE",
                selected = false
            ) {
                val all = VodSubtitleFontSize.values()
                val next = all[(curFont.ordinal + 1) % all.size]
                vodPrefs.setSubtitleFontSize(next)
                subtitleController.applyStylingToPlayerView(playerView)
                Toast.makeText(this, "Subtitle Size: ${next.label}", Toast.LENGTH_SHORT).show()
            }
        )
        val curStyle = vodPrefs.getSubtitleStylePreset()
        items.add(
            PanelRow(
                title = "Subtitle Style: ${curStyle.label}",
                subtitle = "Cycle Cinema Glass / TV Yellow / White Outline / Neon Cyan",
                badge = "STYLE",
                selected = false
            ) {
                val all = VodSubtitleStylePreset.values()
                val next = all[(curStyle.ordinal + 1) % all.size]
                vodPrefs.setSubtitleStylePreset(next)
                subtitleController.applyStylingToPlayerView(playerView)
                Toast.makeText(this, "Subtitle Style: ${next.label}", Toast.LENGTH_SHORT).show()
            }
        )
        items.add(
            PanelRow(
                title = "Subtitle Sync Offset: ${subtitleController.getSubtitleDelayLabel()}",
                subtitle = "Step +250 ms (long range -5000..+5000 ms, resets after +1000 ms)",
                badge = "DELAY",
                selected = vodPrefs.getSubtitleDelayMs() != 0
            ) {
                val cur = vodPrefs.getSubtitleDelayMs()
                val next = if (cur >= 1000) -1000 else cur + 250
                vodPrefs.setSubtitleDelayMs(next)
                Toast.makeText(this, "Subtitle Offset: ${subtitleController.getSubtitleDelayLabel()}", Toast.LENGTH_SHORT).show()
            }
        )
        presentGlassSelectorPanel("Subtitles & Styling", "Current: ${trackManager.getCurrentSubtitleSummary(player)}", items)
    }

    private fun showSpeedSelectorDialog() {
        val player = playbackManager.getPlayer() ?: return
        val current = vodPrefs.getDefaultPlaybackSpeed()
        val items = VodPlaybackSpeed.values().map { sp ->
            PanelRow(
                title = "${sp.label} Playback Speed",
                subtitle = if (sp == VodPlaybackSpeed.SPEED_1_0) "Normal cinema speed" else "Adjust playback pace to ${sp.label}",
                badge = if (sp == current) "ACTIVE ✓" else sp.label,
                selected = sp == current
            ) {
                vodPrefs.setDefaultPlaybackSpeed(sp)
                player.setPlaybackSpeed(sp.rate)
                btnSpeed.text = sp.label
                Toast.makeText(this, "Playback Speed: ${sp.label}", Toast.LENGTH_SHORT).show()
            }
        }
        presentGlassSelectorPanel("Playback Speed", "Select playback speed (0.5x – 2.0x)", items)
    }

    private fun showAspectRatioDialog() {
        val current = vodPrefs.getAspectRatioMode()
        val items = VodAspectRatioMode.values().map { mode ->
            PanelRow(
                title = mode.label,
                subtitle = mode.description,
                badge = if (mode == current) "ACTIVE ✓" else "APPLY",
                selected = mode == current
            ) {
                vodPrefs.setAspectRatioMode(mode)
                playbackManager.applyAspectRatio(playerView, mode)
                btnAspect.text = mode.label
                Toast.makeText(this, "Display Aspect: ${mode.label}", Toast.LENGTH_SHORT).show()
            }
        }
        presentGlassSelectorPanel("Display Aspect Ratio", "Preserve video proportions without distortion", items)
    }

    private fun showEpisodesDrawerDialog() {
        val data = payload ?: return
        if (data.episodes.isEmpty()) return
        val items = data.episodes.map { ep ->
            val isCurrent = ep.episodeId == currentContentId
            val saved = progressStore.getProgressEntry(ep.episodeId, data.accountScope)
            val watched = progressStore.isCompleted(ep.episodeId, data.accountScope)
            val badge = when {
                isCurrent -> "PLAYING"
                saved != null && saved.isResumable() -> "${saved.progressPercent()}%"
                watched -> "WATCHED ✓"
                else -> "PLAY"
            }
            PanelRow(
                title = "${ep.seasonEpisodeBadge()} • ${ep.episodeTitle}",
                subtitle = "Season ${ep.seasonNumber}, Episode ${ep.episodeNumber}" +
                    if (ep.durationLabel.isNotBlank()) " • ${ep.durationLabel}" else "",
                badge = badge,
                selected = isCurrent
            ) {
                if (!isCurrent) {
                    switchToEpisode(ep, resumePositionMs = 0L)
                }
            }
        }
        presentGlassSelectorPanel(
            title = "${data.seriesTitle.ifBlank { "Series" }} — Episodes",
            subtitle = "${data.episodes.size} episodes available",
            rows = items
        )
    }

    private fun showVodSettingsDialog() {
        val curSeek = vodPrefs.getDefaultSeekInterval()
        val curAutoNext = vodPrefs.isAutoNextEpisodeEnabled()
        val curCountdown = vodPrefs.getAutoNextCountdownSec()
        val curResume = vodPrefs.isResumePlaybackEnabled()
        val curHideSec = (vodPrefs.getControlsAutoHideMs() / 1000L).toInt()
        val curSubDefault = vodPrefs.isSubtitlesDefaultEnabled()

        val items = listOf(
            PanelRow(
                title = "Seek Interval: ${curSeek.label}",
                subtitle = "Cycle 5s / 10s / 15s / 20s / 30s / 60s for Left/Right rewind & forward",
                badge = curSeek.label,
                selected = true
            ) {
                val all = VodSeekInterval.values()
                val next = all[(curSeek.ordinal + 1) % all.size]
                vodPrefs.setDefaultSeekInterval(next)
                seekController.setDefaultInterval(next)
                btnRewind.text = "⏪ ${next.label}"
                btnForward.text = "${next.label} ⏩"
                Toast.makeText(this, "Seek Interval: ${next.label}", Toast.LENGTH_SHORT).show()
            },
            PanelRow(
                title = "Auto-Next Episode: ${if (curAutoNext) "ON" else "OFF"}",
                subtitle = "Automatically queue the next series episode near the end",
                badge = if (curAutoNext) "ON ✓" else "OFF",
                selected = curAutoNext
            ) {
                vodPrefs.setAutoNextEpisodeEnabled(!curAutoNext)
                Toast.makeText(this, "Auto-Next Episode: ${if (!curAutoNext) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
            },
            PanelRow(
                title = "Auto-Next Countdown: ${curCountdown}s",
                subtitle = "Cycle countdown duration (5s / 8s / 10s / 15s / 20s)",
                badge = "${curCountdown}s",
                selected = false
            ) {
                val steps = listOf(5, 8, 10, 15, 20)
                val next = steps[(steps.indexOf(curCountdown).coerceAtLeast(0) + 1) % steps.size]
                vodPrefs.setAutoNextCountdownSec(next)
                Toast.makeText(this, "Auto-Next Countdown: ${next}s", Toast.LENGTH_SHORT).show()
            },
            PanelRow(
                title = "Resume Playback Automatically: ${if (curResume) "ON" else "OFF"}",
                subtitle = "Restore saved position for Movies and Series episodes",
                badge = if (curResume) "ON ✓" else "OFF",
                selected = curResume
            ) {
                vodPrefs.setResumePlaybackEnabled(!curResume)
                Toast.makeText(this, "Resume Playback: ${if (!curResume) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
            },
            PanelRow(
                title = "Controls Auto-Hide: ${curHideSec}s",
                subtitle = "Cycle 3s / 5s / 8s / 12s inactivity timeout",
                badge = "${curHideSec}s",
                selected = false
            ) {
                val steps = listOf(3_000L, 5_000L, 8_000L, 12_000L)
                val idx = steps.indexOfFirst { it == vodPrefs.getControlsAutoHideMs() }.coerceAtLeast(0)
                val next = steps[(idx + 1) % steps.size]
                vodPrefs.setControlsAutoHideMs(next)
                Toast.makeText(this, "Controls Auto-Hide: ${next / 1000L}s", Toast.LENGTH_SHORT).show()
            },
            PanelRow(
                title = "Subtitles Default: ${if (curSubDefault) "ON" else "OFF"}",
                subtitle = "Enable subtitles automatically when starting Movies or Series",
                badge = if (curSubDefault) "ON ✓" else "OFF",
                selected = curSubDefault
            ) {
                vodPrefs.setSubtitlesDefaultEnabled(!curSubDefault)
                playbackManager.getPlayer()?.let { subtitleController.applyDefaultSubtitlePreference(it) }
                Toast.makeText(this, "Default Subtitles: ${if (!curSubDefault) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
            },
            PanelRow(
                title = "⏮ Start Current Title from Beginning",
                subtitle = "Seek back to 00:00 and clear current resume marker",
                badge = "RESTART",
                selected = false
            ) {
                payload?.let { progressStore.resetForRewatch(currentContentId, it.accountScope) }
                playbackManager.getPlayer()?.seekTo(0L)
                Toast.makeText(this, "Restarting from 00:00", Toast.LENGTH_SHORT).show()
            }
        )
        presentGlassSelectorPanel("Dedicated VOD Settings", "Saved separately from Live TV preferences", items)
    }

    private data class PanelRow(
        val title: String,
        val subtitle: String,
        val badge: String,
        val selected: Boolean,
        val onClick: () -> Unit
    )

    private fun presentGlassSelectorPanel(title: String, subtitle: String, rows: List<PanelRow>) {
        activeDialog?.dismiss()
        uiHandler.removeCallbacks(hideControlsRunnable)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_vod_glass_panel)
            setPadding(dp(20), dp(18), dp(20), dp(16))
        }

        val tvHead = TextView(this).apply {
            text = title
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        root.addView(tvHead)

        if (subtitle.isNotBlank()) {
            val tvSub = TextView(this).apply {
                text = subtitle
                textSize = 12f
                setTextColor(Color.parseColor("#94A3B8"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4); bottomMargin = dp(12) }
            }
            root.addView(tvSub)
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var firstFocus: View? = null

        for (row in rows) {
            val itemView = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(if (row.selected) R.drawable.bg_vod_primary_play_btn else R.drawable.bg_vod_control_btn)
                setPadding(dp(14), dp(11), dp(14), dp(11))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(7) }
                setOnClickListener {
                    activeDialog?.dismiss()
                    row.onClick()
                    scheduleControlsAutoHide()
                }
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            col.addView(TextView(this).apply {
                text = row.title
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            if (row.subtitle.isNotBlank()) {
                col.addView(TextView(this).apply {
                    text = row.subtitle
                    textSize = 11.5f
                    setTextColor(Color.parseColor("#CBD5E1"))
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                })
            }
            itemView.addView(col)
            itemView.addView(TextView(this).apply {
                text = row.badge
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#38BDF8"))
                setBackgroundResource(R.drawable.bg_badge_neon)
                setPadding(dp(9), dp(4), dp(9), dp(4))
            })
            if (firstFocus == null || row.selected) firstFocus = itemView
            list.addView(itemView)
        }
        scroll.addView(list)
        root.addView(scroll)

        val maxScrollH = (resources.displayMetrics.heightPixels * 0.54f).toInt().coerceAtLeast(dp(180))
        scroll.post {
            if (scroll.height > maxScrollH) {
                scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply { height = maxScrollH }
            }
        }

        val dlg = AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
            .setView(root)
            .setCancelable(true)
            .create()
        dlg.setOnDismissListener { scheduleControlsAutoHide() }
        dlg.show()
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(dp(540).coerceAtMost((resources.displayMetrics.widthPixels * 0.86f).toInt()), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        activeDialog = dlg
        firstFocus?.post { firstFocus?.requestFocus() }
    }

    // =========================================================================
    // ANDROID TV REMOTE CONTROL HANDLING (ZERO LIVE TV INTERFERENCE)
    // =========================================================================

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val action = remoteController.onKeyDown(
            keyCode = keyCode,
            repeatCount = event?.repeatCount ?: 0,
            controlsVisible = controlsVisible,
            sidePanelOpen = activeDialog?.isShowing == true,
            errorOverlayVisible = errorOverlay.visibility == View.VISIBLE,
            autoNextVisible = autoNextCard.visibility == View.VISIBLE,
            seekBarFocused = currentFocus === seekBar
        )
        return when (action) {
            VodRemoteAction.SHOW_CONTROLS_AND_FOCUS_PLAY -> {
                setControlsVisible(true)
                true
            }
            VodRemoteAction.HIDE_CONTROLS -> {
                setControlsVisible(false)
                true
            }
            VodRemoteAction.CLOSE_SIDE_PANEL -> {
                activeDialog?.dismiss()
                true
            }
            VodRemoteAction.TOGGLE_PLAY_PAUSE -> {
                togglePlayPause()
                setControlsVisible(true)
                true
            }
            VodRemoteAction.SEEK_REWIND_STEP -> {
                performStepSeek(isForward = false)
                scheduleControlsAutoHide()
                true
            }
            VodRemoteAction.SEEK_FORWARD_STEP -> {
                performStepSeek(isForward = true)
                scheduleControlsAutoHide()
                true
            }
            VodRemoteAction.SEEK_REWIND_CONTINUOUS -> {
                performContinuousSeekStep(isForward = false)
                true
            }
            VodRemoteAction.SEEK_FORWARD_CONTINUOUS -> {
                performContinuousSeekStep(isForward = true)
                true
            }
            VodRemoteAction.OPEN_SETTINGS_PANEL -> {
                showVodSettingsDialog()
                true
            }
            VodRemoteAction.EXIT_VOD_PLAYER -> {
                exitToDetails()
                true
            }
            VodRemoteAction.RESET_AUTO_HIDE_ONLY -> {
                scheduleControlsAutoHide()
                super.onKeyDown(keyCode, event)
            }
            VodRemoteAction.COMMIT_CONTINUOUS_SEEK,
            VodRemoteAction.NONE -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        val action = remoteController.onKeyUp(keyCode, seekController.isContinuousScrubbing())
        if (action == VodRemoteAction.COMMIT_CONTINUOUS_SEEK) {
            commitContinuousSeek()
            scheduleControlsAutoHide()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun exitToDetails() {
        saveCurrentPlaybackProgress()
        val data = payload
        val resultIntent = Intent().apply {
            putExtra(VodPlayerLauncher.RESULT_RETURN_ACTION, VodPlayerLauncher.ACTION_BACK_TO_DETAILS)
            putExtra(VodPlayerLauncher.RESULT_LAST_CONTENT_ID, currentContentId)
            putExtra(VodPlayerLauncher.RESULT_LAST_SERIES_KEY, currentEpisode?.seriesKey ?: data?.seriesKey.orEmpty())
            putExtra(VodPlayerLauncher.RESULT_LAST_SEASON, currentEpisode?.seasonNumber ?: data?.seasonNumber ?: 1)
        }
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    override fun onPause() {
        super.onPause()
        saveCurrentPlaybackProgress()
        playbackManager.pause()
    }

    override fun onResume() {
        super.onResume()
        if (errorOverlay.visibility != View.VISIBLE && activeDialog?.isShowing != true) {
            playbackManager.resume()
        }
    }

    override fun onStop() {
        super.onStop()
        saveCurrentPlaybackProgress()
        playbackManager.pause()
    }

    override fun onDestroy() {
        uiHandler.removeCallbacksAndMessages(null)
        activeDialog?.dismiss()
        activeDialog = null
        saveCurrentPlaybackProgress()
        playerView.player = null
        playbackManager.release()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()
}
