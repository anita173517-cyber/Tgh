package com.harindra.iptvpro.vod

import android.content.Context
import android.content.SharedPreferences

/**
 * Isolated VOD-specific preferences store (`ram_player_vod_prefs_v21`).
 * NEVER touches or overwrites existing Live TV SharedPreferences keys or ProfileStore schemas.
 */
interface VodPreferencesBacking {
    fun getString(key: String, defValue: String): String
    fun putString(key: String, value: String)
    fun getInt(key: String, defValue: Int): Int
    fun putInt(key: String, value: Int)
    fun getLong(key: String, defValue: Long): Long
    fun putLong(key: String, value: Long)
    fun getFloat(key: String, defValue: Float): Float
    fun putFloat(key: String, value: Float)
    fun getBoolean(key: String, defValue: Boolean): Boolean
    fun putBoolean(key: String, value: Boolean)
}

class SharedPrefsVodBacking(private val prefs: SharedPreferences) : VodPreferencesBacking {
    override fun getString(key: String, defValue: String): String = prefs.getString(key, defValue) ?: defValue
    override fun putString(key: String, value: String) { prefs.edit().putString(key, value).apply() }
    override fun getInt(key: String, defValue: Int): Int = prefs.getInt(key, defValue)
    override fun putInt(key: String, value: Int) { prefs.edit().putInt(key, value).apply() }
    override fun getLong(key: String, defValue: Long): Long = prefs.getLong(key, defValue)
    override fun putLong(key: String, value: Long) { prefs.edit().putLong(key, value).apply() }
    override fun getFloat(key: String, defValue: Float): Float = prefs.getFloat(key, defValue)
    override fun putFloat(key: String, value: Float) { prefs.edit().putFloat(key, value).apply() }
    override fun getBoolean(key: String, defValue: Boolean): Boolean = prefs.getBoolean(key, defValue)
    override fun putBoolean(key: String, value: Boolean) { prefs.edit().putBoolean(key, value).apply() }
}

class InMemoryVodPreferencesBacking : VodPreferencesBacking {
    private val map = HashMap<String, Any>()
    override fun getString(key: String, defValue: String): String = (map[key] as? String) ?: defValue
    override fun putString(key: String, value: String) { map[key] = value }
    override fun getInt(key: String, defValue: Int): Int = (map[key] as? Int) ?: defValue
    override fun putInt(key: String, value: Int) { map[key] = value }
    override fun getLong(key: String, defValue: Long): Long = (map[key] as? Long) ?: defValue
    override fun putLong(key: String, value: Long) { map[key] = value }
    override fun getFloat(key: String, defValue: Float): Float = (map[key] as? Float) ?: defValue
    override fun putFloat(key: String, value: Float) { map[key] = value }
    override fun getBoolean(key: String, defValue: Boolean): Boolean = (map[key] as? Boolean) ?: defValue
    override fun putBoolean(key: String, value: Boolean) { map[key] = value }
}

class VodPreferencesStore(private val backing: VodPreferencesBacking) {

    constructor(context: Context) : this(
        SharedPrefsVodBacking(
            context.applicationContext.getSharedPreferences(PREFS_FILE_NAME, Context.MODE_PRIVATE)
        )
    )

    companion object {
        const val PREFS_FILE_NAME = "ram_player_vod_prefs_v21"

        private const val KEY_SEEK_INTERVAL_MS = "vod_pref_seek_interval_ms"
        private const val KEY_PLAYBACK_SPEED = "vod_pref_playback_speed"
        private const val KEY_DEFAULT_QUALITY = "vod_pref_default_quality"
        private const val KEY_AUDIO_LANG = "vod_pref_audio_language"
        private const val KEY_SUBTITLE_LANG = "vod_pref_subtitle_language"
        private const val KEY_SUBTITLE_ENABLED = "vod_pref_subtitle_enabled"
        private const val KEY_SUBTITLE_FONT_SIZE = "vod_pref_subtitle_font_size"
        private const val KEY_SUBTITLE_STYLE = "vod_pref_subtitle_style"
        private const val KEY_SUBTITLE_DELAY_MS = "vod_pref_subtitle_delay_ms"
        private const val KEY_ASPECT_RATIO = "vod_pref_aspect_ratio"
        private const val KEY_AUTO_NEXT_ENABLED = "vod_pref_auto_next_enabled"
        private const val KEY_AUTO_NEXT_COUNTDOWN_SEC = "vod_pref_auto_next_countdown_sec"
        private const val KEY_RESUME_ENABLED = "vod_pref_resume_enabled"
        private const val KEY_CONTROLS_HIDE_MS = "vod_pref_controls_hide_ms"
    }

    fun getDefaultSeekInterval(): VodSeekInterval {
        return VodSeekInterval.fromMillis(backing.getLong(KEY_SEEK_INTERVAL_MS, VodSeekInterval.SEC_10.millis))
    }

    fun setDefaultSeekInterval(interval: VodSeekInterval) {
        backing.putLong(KEY_SEEK_INTERVAL_MS, interval.millis)
    }

    fun getDefaultPlaybackSpeed(): VodPlaybackSpeed {
        return VodPlaybackSpeed.fromRate(backing.getFloat(KEY_PLAYBACK_SPEED, VodPlaybackSpeed.SPEED_1_0.rate))
    }

    fun setDefaultPlaybackSpeed(speed: VodPlaybackSpeed) {
        backing.putFloat(KEY_PLAYBACK_SPEED, speed.rate)
    }

    fun getDefaultQualityMode(): String {
        return backing.getString(KEY_DEFAULT_QUALITY, "AUTO").ifBlank { "AUTO" }
    }

    fun setDefaultQualityMode(mode: String) {
        backing.putString(KEY_DEFAULT_QUALITY, mode.trim().ifBlank { "AUTO" })
    }

    fun getPreferredAudioLanguage(): String {
        return backing.getString(KEY_AUDIO_LANG, "original").ifBlank { "original" }
    }

    fun setPreferredAudioLanguage(langCode: String) {
        backing.putString(KEY_AUDIO_LANG, langCode.trim().lowercase().ifBlank { "original" })
    }

    fun getPreferredSubtitleLanguage(): String {
        return backing.getString(KEY_SUBTITLE_LANG, "auto").ifBlank { "auto" }
    }

    fun setPreferredSubtitleLanguage(langCode: String) {
        backing.putString(KEY_SUBTITLE_LANG, langCode.trim().lowercase().ifBlank { "auto" })
    }

    fun isSubtitlesDefaultEnabled(): Boolean {
        return backing.getBoolean(KEY_SUBTITLE_ENABLED, false)
    }

    fun setSubtitlesDefaultEnabled(enabled: Boolean) {
        backing.putBoolean(KEY_SUBTITLE_ENABLED, enabled)
    }

    fun getSubtitleFontSize(): VodSubtitleFontSize {
        return VodSubtitleFontSize.fromId(backing.getString(KEY_SUBTITLE_FONT_SIZE, VodSubtitleFontSize.MEDIUM.id))
    }

    fun setSubtitleFontSize(size: VodSubtitleFontSize) {
        backing.putString(KEY_SUBTITLE_FONT_SIZE, size.id)
    }

    fun getSubtitleStylePreset(): VodSubtitleStylePreset {
        return VodSubtitleStylePreset.fromId(backing.getString(KEY_SUBTITLE_STYLE, VodSubtitleStylePreset.CINEMA_GLASS.id))
    }

    fun setSubtitleStylePreset(preset: VodSubtitleStylePreset) {
        backing.putString(KEY_SUBTITLE_STYLE, preset.id)
    }

    fun getSubtitleDelayMs(): Int {
        return backing.getInt(KEY_SUBTITLE_DELAY_MS, 0).coerceIn(-5000, 5000)
    }

    fun setSubtitleDelayMs(delayMs: Int) {
        backing.putInt(KEY_SUBTITLE_DELAY_MS, delayMs.coerceIn(-5000, 5000))
    }

    fun getAspectRatioMode(): VodAspectRatioMode {
        return VodAspectRatioMode.fromId(backing.getString(KEY_ASPECT_RATIO, VodAspectRatioMode.FIT.id))
    }

    fun setAspectRatioMode(mode: VodAspectRatioMode) {
        backing.putString(KEY_ASPECT_RATIO, mode.id)
    }

    fun isAutoNextEpisodeEnabled(): Boolean {
        return backing.getBoolean(KEY_AUTO_NEXT_ENABLED, true)
    }

    fun setAutoNextEpisodeEnabled(enabled: Boolean) {
        backing.putBoolean(KEY_AUTO_NEXT_ENABLED, enabled)
    }

    fun getAutoNextCountdownSec(): Int {
        return backing.getInt(KEY_AUTO_NEXT_COUNTDOWN_SEC, 10).coerceIn(5, 20)
    }

    fun setAutoNextCountdownSec(seconds: Int) {
        backing.putInt(KEY_AUTO_NEXT_COUNTDOWN_SEC, seconds.coerceIn(5, 20))
    }

    fun isResumePlaybackEnabled(): Boolean {
        return backing.getBoolean(KEY_RESUME_ENABLED, true)
    }

    fun setResumePlaybackEnabled(enabled: Boolean) {
        backing.putBoolean(KEY_RESUME_ENABLED, enabled)
    }

    fun getControlsAutoHideMs(): Long {
        return backing.getLong(KEY_CONTROLS_HIDE_MS, 5_000L).coerceIn(3_000L, 15_000L)
    }

    fun setControlsAutoHideMs(durationMs: Long) {
        backing.putLong(KEY_CONTROLS_HIDE_MS, durationMs.coerceIn(3_000L, 15_000L))
    }
}
