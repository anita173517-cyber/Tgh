package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveTvBackgroundPlaybackControllerTest {

    @Test
    fun liveTvSuspendsWhenLeavingLiveSectionAndPreferenceEnabled() {
        assertTrue(
            LiveTvBackgroundPlaybackController.shouldSuspendLiveTvForSection(
                isLiveTvPlaybackMode = true,
                isInPictureInPictureMode = false,
                stopInBackgroundSettingEnabled = true
            )
        )
    }

    @Test
    fun liveTvDoesNotSuspendForPipVodOrDisabledPreference() {
        assertFalse(
            LiveTvBackgroundPlaybackController.shouldSuspendLiveTvForSection(
                isLiveTvPlaybackMode = true,
                isInPictureInPictureMode = true,
                stopInBackgroundSettingEnabled = true
            )
        )
        assertFalse(
            LiveTvBackgroundPlaybackController.shouldSuspendLiveTvForSection(
                isLiveTvPlaybackMode = false,
                isInPictureInPictureMode = false,
                stopInBackgroundSettingEnabled = true
            )
        )
        assertFalse(
            LiveTvBackgroundPlaybackController.shouldSuspendLiveTvForSection(
                isLiveTvPlaybackMode = true,
                isInPictureInPictureMode = false,
                stopInBackgroundSettingEnabled = false
            )
        )
    }

    @Test
    fun suspendedChannelStateCanBeRestoredOnce() {
        LiveTvBackgroundPlaybackController.clearSuspendedState()
        val saved = LiveTvBackgroundPlaybackController.recordLiveTvSuspended(
            channelIndex = 7,
            channelId = "channel-7",
            channelName = "News",
            targetSectionName = "Settings",
            nowMs = 1234L
        )
        assertTrue(saved.wasSuspended)
        assertEquals(7, saved.channelIndex)
        assertEquals("channel-7", saved.channelId)

        val consumed = LiveTvBackgroundPlaybackController.consumeSuspendedState()
        assertTrue(consumed.wasSuspended)
        assertEquals("Settings", consumed.sectionEntered)
        assertFalse(LiveTvBackgroundPlaybackController.peekSuspendedState().wasSuspended)
    }
}
