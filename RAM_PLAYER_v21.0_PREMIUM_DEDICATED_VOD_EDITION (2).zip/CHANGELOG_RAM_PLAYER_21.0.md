# RAM PLAYER v21.0 — EXTREME AUDIO & PLAYLIST COMPATIBILITY MASTER UPGRADE

- **Version**: `21.0` (`versionCode = 210`, `applicationId = com.harindra.iptvpro`)
- **Base Foundation**: Upgraded directly on top of `RAM_PLAYER_v20.0_Final_Ultimate_Edition.zip` (zero duplication, full backward compatibility with v20.0 profiles, playlists, settings, and backups).
- **Target Devices**: 512MB, 1GB, 2GB, and 4GB+ Android TV & Android Mobile devices (`minSdk = 23`, `targetSdk = 34`, `compileSdk = 36`).

## 1. Critical Audio Fix (Video Without Audio)
- **HLS Chunkless Preparation Fix (`PlayerActivity.kt`)**: Disabled `allowChunklessPreparation(false)` on `HlsMediaSource.Factory` so IPTV MPEG-TS / HLS streams lacking `CODECS` attributes in master manifests always probe elementary audio streams cleanly.
- **Audio Sink & Decoder Fallback (`PlayerActivity.kt`, `AudioDelayProcessor.kt`)**:
  - Enabled `DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON`, `setEnableDecoderFallback(true)`, `AudioCapabilities.getCapabilities(context)`, and `setEnableAudioTrackPlaybackParams(true)`.
  - Fixed `AudioDelayProcessor.onConfigure` to bypass cleanly (`AudioFormat.NOT_SET`) at `0ms` delay so native float/passthrough/offload paths are untouched, while supporting both `ENCODING_PCM_16BIT` and `ENCODING_PCM_FLOAT` with a 512KB RAM cap when delay > 0.
- **Intelligent Audio Track Detection & Bounded Automatic Recovery (`SmartEngineHub.kt`, `PlayerActivity.kt`)**:
  - Added `AudioTrackIntelligenceEngine` prioritizing preferred language -> Hindi (`hi`/`hin`) -> English (`en`/`eng`) -> any valid supported track, never selecting an unsupported track.
  - Added `onTracksChanged` + `AnalyticsListener` (`onAudioCodecError`, `onAudioSinkError`) with bounded retries (max 2 attempts, 3.5s cooldown) and safe PCM fallback.
- **Genuine Audio Diagnostics & Audio HD Controls (`PlayerActivity.kt`, `ProfileStore.kt`)**:
  - Fixed `updateLiveTelemetryBadge` so it never falsely displays `"STEREO"` when audio is missing (`NO AUDIO` / `UNSUPPORTED AUD` / `AUD DEC ERR`).
  - Added Audio Diagnostics card, profile-aware Preferred Audio Language, Loudness Boost (+0 to +9 dB), and Reset All Audio Settings inside the existing Audio HD dialog.
  - *Technical Limitation Note*: Official Media3 FFmpeg decoder (`media3-decoder-ffmpeg`) is not published on Google Maven and requires native NDK C compilation; therefore, RAM PLAYER v21.0 uses Android's hardware/software `MediaCodec` + Media3 `DefaultAudioSink` decoders with `EXTENSION_RENDERER_MODE_ON` and `setEnableDecoderFallback(true)` without advertising unsupported codecs.

## 2. Universal M3U / M3U8 & Scoped Header Fix
- **NetworkClient Header Leak Fix (`NetworkClient.kt`)**: Removed the v20.0 host-wide `hostStreamHeaders[host]` map that caused Channel A's headers to leak onto Channel B on the same provider host. Replaced with a 4-tier scoped registry (exact URL, explicit redirect/variant URL, base-no-query URL, and channel-scoped directory prefix) with cross-host `Authorization` / `Cookie` protection.
- **M3uParser (`M3uParser.kt`)**: Added relative URL resolution (`baseUrl`), word-boundary attribute parsing, `#EXTVLCOPT:http-authorization`, extended `#KODIPROP` (`manifest_headers`, `stream_headers`, direct UA/Referer), `mms://`/`mmsh://` schemes, and `parseWithStats(...)` diagnostics.

## 3. Xtream Codes Compatibility (`XtreamRepository.kt`)
- Added `validateAccount(creds)` querying `player_api.php` to validate login, detect expired sessions, and discover `user_info.allowed_output_formats`.
- Added `buildLiveStreamUrls(...)` selecting server-supported primary/backup stream formats (`m3u8` / `ts`) instead of hardcoding `.m3u8`.

## 4. Universal Channel Playback Recovery (`SmartEngineHub.kt`, `PlayerActivity.kt`)
- Added `PlaybackRecoveryEngine.classifyFailure(...)` distinguishing 401/403 Auth, 404/410 Not Found, 429 Rate Limit, 5xx Server, Connection Timeout, DNS Error, HLS Manifest Error, Missing Segment, Unsupported Codec, Decoder Init Failed, and Live Window Drift.

## 5. Complete Category Delete, Individual Channel Delete, 5-Second OK Hold Delete & Expanded Recycle Bin
- **Complete Category Delete (`ProfileStore.kt`, `PlayerActivity.kt`)**: Persistent, profile-isolated soft-delete (`showCategoryManagerDialog`) with channel counts, confirmation, Undo, and Restore. Persists across restarts, refreshes, and re-imports without touching remote playlists.
- **Individual Channel Delete (`ProfileStore.kt`, `PlayerActivity.kt`)**: Persistent soft-delete keyed by `Channel.deletionKey()` + `channel.id`, integrated into Channel Management and restorable from Recycle Bin.
- **5-Second OK/ENTER Hold Delete (`OkLongHoldDeleteController`, `PlayerActivity.kt`, `activity_player.xml`)**: Monotonic `elapsedRealtime()` hold tracking for `KEYCODE_DPAD_CENTER`, `KEYCODE_ENTER`, `KEYCODE_NUMPAD_ENTER` with visible glass countdown overlay (`okHoldDeleteOverlay`), repeat-event guard, early-release cancellation, focus-loss cancellation, zero conflict with configurable short Long-Press OK, and mandatory confirmation dialog showing exact channel number and name.
- **Genuine Recycle Bin (`ProfileStore.kt`, `PlayerActivity.kt`)**: Expanded to `"CHANNEL"`, `"CATEGORY"`, `"CUSTOM_GROUP"`, and `"PROFILE"` with Search, Restore Individual, Restore Selected, Restore All, Permanent Delete, Empty Bin, and **encrypted profile passwords** stored in `securePrefs` (never plain text in Recycle Bin JSON).

## 6. Default Performance Profiles & Fast Zapping (`Models.kt`, `StreamPreFetcher.kt`)
- Updated `DeviceOptimizationProfile.resolve` to default to `AUTO_ADAPTIVE` across 512MB/1GB (`LOW_MEMORY`), 2GB (`SMART_BALANCED`), and 4GB+ (`HIGH_PERFORMANCE_4GB`) with automatic memory-pressure and JVM heap-limit fallbacks.
- Enhanced `StreamPreFetcher` with scoped redirect/variant header propagation, expired query-token detection (`exp=`/`expires=`), dynamic RAM budget, and recently watched URL tracking.

## 7. Automated Unit Tests & Build Verification
- Added `RamPlayerV21MasterTest.kt` alongside existing `M3uParserTest.kt` and `LiveTvBackgroundPlaybackControllerTest.kt`.
- Updated `.github/workflows/build_apk.yml` (Gradle 8.13, SDK 36, JDK 17, runs `verify_project.py`, `testDebugUnitTest`, `assembleDebug`, and `assembleRelease`).
- *Environment Note*: Because this offline build environment has no Android SDK or outbound internet access, APK compilation and Gradle unit test execution run in GitHub Actions (`.github/workflows/build_apk.yml`), while full offline XML, resource, R-symbol, brace, and static verification passed via `scripts/verify_project.py`.
